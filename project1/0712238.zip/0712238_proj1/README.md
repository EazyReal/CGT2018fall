# TDL2048-Demo
Basic Environment for Game 2048 (Demo)<br>
<p>
Computer Games and Intelligence (CGI) Lab, NCTU, Taiwan<br>
http://www.aigames.nctu.edu.tw/<br>
<p>